function enviar(){
    document.getElementById('txtNom').value="";
    document.getElementById('txtEmail').value="";
    document.getElementById('txtCall').value="";
    document.getElementById('txtArea').value="";
    document.getElementById('txtNom').focus();
}